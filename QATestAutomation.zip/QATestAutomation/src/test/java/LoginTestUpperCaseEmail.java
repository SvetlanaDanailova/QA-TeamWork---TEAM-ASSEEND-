
import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;

public class LoginTestUpperCaseEmail {
    private WebDriver driver;

    @Before
    public void setUp() {
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }

    @Test
    public void Test_Login_Upper_Case_Username() {

        driver.get("https://www.gmail.com/intl/bg/mail/help/about.html");

        String validEmail = "TESTINGTEAMWORK1@GMAIL.COM";
        String validPassword = "TESTINGTEAMWORK";

        WebElement log = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/a[1]"));
        log.click();

        try {


            WebElement emailField = driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/div[1]/form/div[1]/div/div[1]/div/div/input[1]"));
            emailField.clear();
            emailField.sendKeys(validEmail);

            WebElement next = driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/div[1]/form/div[1]/div/input"));
            next.click();

            WebElement passwordField = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/form/div[2]/div/div[2]/div/div/input[2]"));

            passwordField.clear();
            passwordField.sendKeys(validPassword);

            WebElement loginButton = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/form/div[2]/div/input[1]"));
            loginButton.click();



        } catch (IndexOutOfBoundsException e) {
            assertEquals("������� � ��������, ����� ���������, �� �� ������������.", e.getMessage());

        }


    }

            @After
            public void tearDown () {
                String validPassword1 = "testingteamwork";

                WebElement passwordField = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/form/div[2]/div/div[2]/div/div/input[2]"));

                passwordField.clear();
                passwordField.sendKeys(validPassword1);

                WebElement loginButton = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/form/div[2]/div/input[1]"));
                loginButton.click();

                assertEquals("https://mail.google.com/mail/", driver.getCurrentUrl());


            }

     }
